$(document).ready(function(){
	$("#btn-yes").click(function(){
		$("#result").html("<img src='yes.jpg' style='width:300px;'>");
	});

	$("#btn-no").click(function(){
		$("#result").html("<img src='no.jpg' style='width:300px;'>");
	});	
});